# chatwoot/client

This is the API documentation for Chatwoot server.


## Installation & Usage

### Requirements

PHP 7.4 and later.
Should also work with PHP 8.0.

### Composer

To install the bindings via [Composer](https://getcomposer.org/), add the following to `composer.json`:

```json
{
  "repositories": [
    {
      "type": "vcs",
      "url": "https://github.com/GIT_USER_ID/GIT_REPO_ID.git"
    }
  ],
  "require": {
    "GIT_USER_ID/GIT_REPO_ID": "*@dev"
  }
}
```

Then run `composer install`

### Manual Installation

Download the files and include `autoload.php`:

```php
<?php
require_once('/path/to/chatwoot/client/vendor/autoload.php');
```

## Getting Started

Please follow the [installation procedure](#installation--usage) and then run the following:

```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');



// Configure API key authorization: userApiKey
$config = Chatwoot\Client\Configuration::getDefaultConfiguration()->setApiKey('api_access_token', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// $config = Chatwoot\Client\Configuration::getDefaultConfiguration()->setApiKeyPrefix('api_access_token', 'Bearer');


$apiInstance = new Chatwoot\Client\Api\AccountAgentBotsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$account_id = 56; // int | The numeric ID of the account
$data = new \Chatwoot\Client\Model\AgentBotCreateUpdatePayload(); // \Chatwoot\Client\Model\AgentBotCreateUpdatePayload

try {
    $result = $apiInstance->createAnAccountAgentBot($account_id, $data);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling AccountAgentBotsApi->createAnAccountAgentBot: ', $e->getMessage(), PHP_EOL;
}

```

## API Endpoints

All URIs are relative to *https://app.chatwoot.com*

Class | Method | HTTP request | Description
------------ | ------------- | ------------- | -------------
*AccountAgentBotsApi* | [**createAnAccountAgentBot**](docs/Api/AccountAgentBotsApi.md#createanaccountagentbot) | **POST** /api/v1/accounts/{account_id}/agent_bots | Create an Agent Bot
*AccountAgentBotsApi* | [**deleteAnAccountAgentBot**](docs/Api/AccountAgentBotsApi.md#deleteanaccountagentbot) | **DELETE** /api/v1/accounts/{account_id}/agent_bots/{id} | Delete an AgentBot
*AccountAgentBotsApi* | [**getDetailsOfASingleAccountAgentBot**](docs/Api/AccountAgentBotsApi.md#getdetailsofasingleaccountagentbot) | **GET** /api/v1/accounts/{account_id}/agent_bots/{id} | Get an agent bot details
*AccountAgentBotsApi* | [**listAllAccountAgentBots**](docs/Api/AccountAgentBotsApi.md#listallaccountagentbots) | **GET** /api/v1/accounts/{account_id}/agent_bots | List all AgentBots
*AccountAgentBotsApi* | [**updateAnAccountAgentBot**](docs/Api/AccountAgentBotsApi.md#updateanaccountagentbot) | **PATCH** /api/v1/accounts/{account_id}/agent_bots/{id} | Update an agent bot
*AccountUsersApi* | [**createAnAccountUser**](docs/Api/AccountUsersApi.md#createanaccountuser) | **POST** /platform/api/v1/accounts/{account_id}/account_users | Create an Account User
*AccountUsersApi* | [**deleteAnAccountUser**](docs/Api/AccountUsersApi.md#deleteanaccountuser) | **DELETE** /platform/api/v1/accounts/{account_id}/account_users | Delete an Account User
*AccountUsersApi* | [**listAllAccountUsers**](docs/Api/AccountUsersApi.md#listallaccountusers) | **GET** /platform/api/v1/accounts/{account_id}/account_users | List all Account Users
*AccountsApi* | [**createAnAccount**](docs/Api/AccountsApi.md#createanaccount) | **POST** /platform/api/v1/accounts | Create an Account
*AccountsApi* | [**deleteAnAccount**](docs/Api/AccountsApi.md#deleteanaccount) | **DELETE** /platform/api/v1/accounts/{account_id} | Delete an Account
*AccountsApi* | [**getDetailsOfAnAccount**](docs/Api/AccountsApi.md#getdetailsofanaccount) | **GET** /platform/api/v1/accounts/{account_id} | Get an account details
*AccountsApi* | [**updateAnAccount**](docs/Api/AccountsApi.md#updateanaccount) | **PATCH** /platform/api/v1/accounts/{account_id} | Update an account
*AgentBotsApi* | [**createAnAgentBot**](docs/Api/AgentBotsApi.md#createanagentbot) | **POST** /platform/api/v1/agent_bots | Create an Agent Bot
*AgentBotsApi* | [**deleteAnAgentBot**](docs/Api/AgentBotsApi.md#deleteanagentbot) | **DELETE** /platform/api/v1/agent_bots/{id} | Delete an AgentBot
*AgentBotsApi* | [**getDetailsOfASingleAgentBot**](docs/Api/AgentBotsApi.md#getdetailsofasingleagentbot) | **GET** /platform/api/v1/agent_bots/{id} | Get an agent bot details
*AgentBotsApi* | [**listAllAgentBots**](docs/Api/AgentBotsApi.md#listallagentbots) | **GET** /platform/api/v1/agent_bots | List all AgentBots
*AgentBotsApi* | [**updateAnAgentBot**](docs/Api/AgentBotsApi.md#updateanagentbot) | **PATCH** /platform/api/v1/agent_bots/{id} | Update an agent bot
*AgentsApi* | [**addNewAgentToAccount**](docs/Api/AgentsApi.md#addnewagenttoaccount) | **POST** /api/v1/accounts/{account_id}/agents | Add a New Agent
*AgentsApi* | [**deleteAgentFromAccount**](docs/Api/AgentsApi.md#deleteagentfromaccount) | **DELETE** /api/v1/accounts/{account_id}/agents/{id} | Remove an Agent from Account
*AgentsApi* | [**getAccountAgents**](docs/Api/AgentsApi.md#getaccountagents) | **GET** /api/v1/accounts/{account_id}/agents | List Agents in Account
*AgentsApi* | [**updateAgentInAccount**](docs/Api/AgentsApi.md#updateagentinaccount) | **PATCH** /api/v1/accounts/{account_id}/agents/{id} | Update Agent in Account
*AutomationRuleApi* | [**addNewAutomationRuleToAccount**](docs/Api/AutomationRuleApi.md#addnewautomationruletoaccount) | **POST** /api/v1/accounts/{account_id}/automation_rules | Add a new automation rule
*AutomationRuleApi* | [**deleteAutomationRuleFromAccount**](docs/Api/AutomationRuleApi.md#deleteautomationrulefromaccount) | **DELETE** /api/v1/accounts/{account_id}/automation_rules/{id} | Remove a automation rule from account
*AutomationRuleApi* | [**getAccountAutomationRule**](docs/Api/AutomationRuleApi.md#getaccountautomationrule) | **GET** /api/v1/accounts/{account_id}/automation_rules | List all automation rules in an account
*AutomationRuleApi* | [**getDetailsOfASingleAutomationRule**](docs/Api/AutomationRuleApi.md#getdetailsofasingleautomationrule) | **GET** /api/v1/accounts/{account_id}/automation_rules/{id} | Get a automation rule details
*AutomationRuleApi* | [**updateAutomationRuleInAccount**](docs/Api/AutomationRuleApi.md#updateautomationruleinaccount) | **PATCH** /api/v1/accounts/{account_id}/automation_rules/{id} | Update automation rule in Account
*CSATSurveyPageApi* | [**getCsatSurveyPage**](docs/Api/CSATSurveyPageApi.md#getcsatsurveypage) | **GET** /survey/responses/{conversation_uuid} | Get CSAT survey page
*CannedResponseApi* | [**updateCannedResponseInAccount**](docs/Api/CannedResponseApi.md#updatecannedresponseinaccount) | **PATCH** /api/v1/accounts/{account_id}/canned_responses/{id} | Update Canned Response in Account
*CannedResponsesApi* | [**addNewCannedResponseToAccount**](docs/Api/CannedResponsesApi.md#addnewcannedresponsetoaccount) | **POST** /api/v1/accounts/{account_id}/canned_responses | Add a New Canned Response
*CannedResponsesApi* | [**deleteCannedResponseFromAccount**](docs/Api/CannedResponsesApi.md#deletecannedresponsefromaccount) | **DELETE** /api/v1/accounts/{account_id}/canned_responses/{id} | Remove a Canned Response from Account
*CannedResponsesApi* | [**getAccountCannedResponse**](docs/Api/CannedResponsesApi.md#getaccountcannedresponse) | **GET** /api/v1/accounts/{account_id}/canned_responses | List all Canned Responses in an Account
*ContactApi* | [**contactInboxCreation**](docs/Api/ContactApi.md#contactinboxcreation) | **POST** /api/v1/accounts/{account_id}/contacts/{id}/contact_inboxes | Create contact inbox
*ContactApi* | [**contactableInboxesGet**](docs/Api/ContactApi.md#contactableinboxesget) | **GET** /api/v1/accounts/{account_id}/contacts/{id}/contactable_inboxes | Get Contactable Inboxes
*ContactLabelsApi* | [**contactAddLabels**](docs/Api/ContactLabelsApi.md#contactaddlabels) | **POST** /api/v1/accounts/{account_id}/contacts/{contact_identifier}/labels | Add Labels
*ContactLabelsApi* | [**listAllLabelsOfAContact**](docs/Api/ContactLabelsApi.md#listalllabelsofacontact) | **GET** /api/v1/accounts/{account_id}/contacts/{contact_identifier}/labels | List Labels
*ContactsApi* | [**contactConversations**](docs/Api/ContactsApi.md#contactconversations) | **GET** /api/v1/accounts/{account_id}/contacts/{id}/conversations | Contact Conversations
*ContactsApi* | [**contactCreate**](docs/Api/ContactsApi.md#contactcreate) | **POST** /api/v1/accounts/{account_id}/contacts | Create Contact
*ContactsApi* | [**contactDelete**](docs/Api/ContactsApi.md#contactdelete) | **DELETE** /api/v1/accounts/{account_id}/contacts/{id} | Delete Contact
*ContactsApi* | [**contactDetails**](docs/Api/ContactsApi.md#contactdetails) | **GET** /api/v1/accounts/{account_id}/contacts/{id} | Show Contact
*ContactsApi* | [**contactFilter**](docs/Api/ContactsApi.md#contactfilter) | **POST** /api/v1/accounts/{account_id}/contacts/filter | Contact Filter
*ContactsApi* | [**contactList**](docs/Api/ContactsApi.md#contactlist) | **GET** /api/v1/accounts/{account_id}/contacts | List Contacts
*ContactsApi* | [**contactSearch**](docs/Api/ContactsApi.md#contactsearch) | **GET** /api/v1/accounts/{account_id}/contacts/search | Search Contacts
*ContactsApi* | [**contactUpdate**](docs/Api/ContactsApi.md#contactupdate) | **PUT** /api/v1/accounts/{account_id}/contacts/{id} | Update Contact
*ContactsAPIApi* | [**createAContact**](docs/Api/ContactsAPIApi.md#createacontact) | **POST** /public/api/v1/inboxes/{inbox_identifier}/contacts | Create a contact
*ContactsAPIApi* | [**getDetailsOfAContact**](docs/Api/ContactsAPIApi.md#getdetailsofacontact) | **GET** /public/api/v1/inboxes/{inbox_identifier}/contacts/{contact_identifier} | Get a contact
*ContactsAPIApi* | [**updateAContact**](docs/Api/ContactsAPIApi.md#updateacontact) | **PATCH** /public/api/v1/inboxes/{inbox_identifier}/contacts/{contact_identifier} | Update a contact
*ConversationAssignmentApi* | [**assignAConversation**](docs/Api/ConversationAssignmentApi.md#assignaconversation) | **POST** /api/v1/accounts/{account_id}/conversations/{conversation_id}/assignments | Assign Conversation
*ConversationLabelsApi* | [**conversationAddLabels**](docs/Api/ConversationLabelsApi.md#conversationaddlabels) | **POST** /api/v1/accounts/{account_id}/conversations/{conversation_id}/labels | Add Labels
*ConversationLabelsApi* | [**listAllLabelsOfAConversation**](docs/Api/ConversationLabelsApi.md#listalllabelsofaconversation) | **GET** /api/v1/accounts/{account_id}/conversations/{conversation_id}/labels | List Labels
*ConversationsApi* | [**conversationFilter**](docs/Api/ConversationsApi.md#conversationfilter) | **POST** /api/v1/accounts/{account_id}/conversations/filter | Conversations Filter
*ConversationsApi* | [**conversationList**](docs/Api/ConversationsApi.md#conversationlist) | **GET** /api/v1/accounts/{account_id}/conversations | Conversations List
*ConversationsApi* | [**conversationListMeta**](docs/Api/ConversationsApi.md#conversationlistmeta) | **GET** /api/v1/accounts/{account_id}/conversations/meta | Get Conversation Counts
*ConversationsApi* | [**getDetailsOfAConversation**](docs/Api/ConversationsApi.md#getdetailsofaconversation) | **GET** /api/v1/accounts/{account_id}/conversations/{conversation_id} | Conversation Details
*ConversationsApi* | [**newConversation**](docs/Api/ConversationsApi.md#newconversation) | **POST** /api/v1/accounts/{account_id}/conversations | Create New Conversation
*ConversationsApi* | [**togglePriorityOfAConversation**](docs/Api/ConversationsApi.md#togglepriorityofaconversation) | **POST** /api/v1/accounts/{account_id}/conversations/{conversation_id}/toggle_priority | Toggle Priority
*ConversationsApi* | [**toggleStatusOfAConversation**](docs/Api/ConversationsApi.md#togglestatusofaconversation) | **POST** /api/v1/accounts/{account_id}/conversations/{conversation_id}/toggle_status | Toggle Status
*ConversationsApi* | [**updateConversation**](docs/Api/ConversationsApi.md#updateconversation) | **PATCH** /api/v1/accounts/{account_id}/conversations/{conversation_id} | Update Conversation
*ConversationsApi* | [**updateCustomAttributesOfAConversation**](docs/Api/ConversationsApi.md#updatecustomattributesofaconversation) | **POST** /api/v1/accounts/{account_id}/conversations/{conversation_id}/custom_attributes | Update Custom Attributes
*ConversationsAPIApi* | [**createAConversation**](docs/Api/ConversationsAPIApi.md#createaconversation) | **POST** /public/api/v1/inboxes/{inbox_identifier}/contacts/{contact_identifier}/conversations | Create a conversation
*ConversationsAPIApi* | [**getSingleConversation**](docs/Api/ConversationsAPIApi.md#getsingleconversation) | **GET** /public/api/v1/inboxes/{inbox_identifier}/contacts/{contact_identifier}/conversations/{conversation_id} | Get a single conversation
*ConversationsAPIApi* | [**listAllContactConversations**](docs/Api/ConversationsAPIApi.md#listallcontactconversations) | **GET** /public/api/v1/inboxes/{inbox_identifier}/contacts/{contact_identifier}/conversations | List all conversations
*ConversationsAPIApi* | [**resolveConversation**](docs/Api/ConversationsAPIApi.md#resolveconversation) | **POST** /public/api/v1/inboxes/{inbox_identifier}/contacts/{contact_identifier}/conversations/{conversation_id}/toggle_status | Resolve a conversation
*ConversationsAPIApi* | [**toggleTypingStatus**](docs/Api/ConversationsAPIApi.md#toggletypingstatus) | **POST** /public/api/v1/inboxes/{inbox_identifier}/contacts/{contact_identifier}/conversations/{conversation_id}/toggle_typing | Toggle typing status
*ConversationsAPIApi* | [**updateLastSeen**](docs/Api/ConversationsAPIApi.md#updatelastseen) | **POST** /public/api/v1/inboxes/{inbox_identifier}/contacts/{contact_identifier}/conversations/{conversation_id}/update_last_seen | Update last seen
*CustomAttributesApi* | [**addNewCustomAttributeToAccount**](docs/Api/CustomAttributesApi.md#addnewcustomattributetoaccount) | **POST** /api/v1/accounts/{account_id}/custom_attribute_definitions | Add a new custom attribute
*CustomAttributesApi* | [**deleteCustomAttributeFromAccount**](docs/Api/CustomAttributesApi.md#deletecustomattributefromaccount) | **DELETE** /api/v1/accounts/{account_id}/custom_attribute_definitions/{id} | Remove a custom attribute from account
*CustomAttributesApi* | [**getAccountCustomAttribute**](docs/Api/CustomAttributesApi.md#getaccountcustomattribute) | **GET** /api/v1/accounts/{account_id}/custom_attribute_definitions | List all custom attributes in an account
*CustomAttributesApi* | [**getDetailsOfASingleCustomAttribute**](docs/Api/CustomAttributesApi.md#getdetailsofasinglecustomattribute) | **GET** /api/v1/accounts/{account_id}/custom_attribute_definitions/{id} | Get a custom attribute details
*CustomAttributesApi* | [**updateCustomAttributeInAccount**](docs/Api/CustomAttributesApi.md#updatecustomattributeinaccount) | **PATCH** /api/v1/accounts/{account_id}/custom_attribute_definitions/{id} | Update custom attribute in Account
*CustomFiltersApi* | [**createACustomFilter**](docs/Api/CustomFiltersApi.md#createacustomfilter) | **POST** /api/v1/accounts/{account_id}/custom_filters | Create a custom filter
*CustomFiltersApi* | [**deleteACustomFilter**](docs/Api/CustomFiltersApi.md#deleteacustomfilter) | **DELETE** /api/v1/accounts/{account_id}/custom_filters/{custom_filter_id} | Delete a custom filter
*CustomFiltersApi* | [**getDetailsOfASingleCustomFilter**](docs/Api/CustomFiltersApi.md#getdetailsofasinglecustomfilter) | **GET** /api/v1/accounts/{account_id}/custom_filters/{custom_filter_id} | Get a custom filter details
*CustomFiltersApi* | [**listAllFilters**](docs/Api/CustomFiltersApi.md#listallfilters) | **GET** /api/v1/accounts/{account_id}/custom_filters | List all custom filters
*CustomFiltersApi* | [**updateACustomFilter**](docs/Api/CustomFiltersApi.md#updateacustomfilter) | **PATCH** /api/v1/accounts/{account_id}/custom_filters/{custom_filter_id} | Update a custom filter
*HelpCenterApi* | [**addNewArticleToAccount**](docs/Api/HelpCenterApi.md#addnewarticletoaccount) | **POST** /api/v1/accounts/{account_id}/portals/{portal_id}/articles | Add a new article
*HelpCenterApi* | [**addNewCategoryToAccount**](docs/Api/HelpCenterApi.md#addnewcategorytoaccount) | **POST** /api/v1/accounts/{account_id}/portals/{portal_id}/categories | Add a new category
*HelpCenterApi* | [**addNewPortalToAccount**](docs/Api/HelpCenterApi.md#addnewportaltoaccount) | **POST** /api/v1/accounts/{account_id}/portals | Add a new portal
*HelpCenterApi* | [**getPortal**](docs/Api/HelpCenterApi.md#getportal) | **GET** /api/v1/accounts/{account_id}/portals | List all portals in an account
*HelpCenterApi* | [**updateNewPortalToAccount**](docs/Api/HelpCenterApi.md#updatenewportaltoaccount) | **PATCH** /api/v1/accounts/{account_id}/portals | update a new portal
*InboxAPIApi* | [**getDetailsOfAInbox**](docs/Api/InboxAPIApi.md#getdetailsofainbox) | **GET** /public/api/v1/inboxes/{inbox_identifier} | Inbox details
*InboxesApi* | [**addNewAgentToInbox**](docs/Api/InboxesApi.md#addnewagenttoinbox) | **POST** /api/v1/accounts/{account_id}/inbox_members | Add a New Agent
*InboxesApi* | [**deleteAgentInInbox**](docs/Api/InboxesApi.md#deleteagentininbox) | **DELETE** /api/v1/accounts/{account_id}/inbox_members | Remove an Agent from Inbox
*InboxesApi* | [**getInbox**](docs/Api/InboxesApi.md#getinbox) | **GET** /api/v1/accounts/{account_id}/inboxes/{id}/ | Get an inbox
*InboxesApi* | [**getInboxAgentBot**](docs/Api/InboxesApi.md#getinboxagentbot) | **GET** /api/v1/accounts/{account_id}/inboxes/{id}/agent_bot | Show Inbox Agent Bot
*InboxesApi* | [**getInboxMembers**](docs/Api/InboxesApi.md#getinboxmembers) | **GET** /api/v1/accounts/{account_id}/inbox_members/{inbox_id} | List Agents in Inbox
*InboxesApi* | [**inboxCreation**](docs/Api/InboxesApi.md#inboxcreation) | **POST** /api/v1/accounts/{account_id}/inboxes/ | Create an inbox
*InboxesApi* | [**listAllInboxes**](docs/Api/InboxesApi.md#listallinboxes) | **GET** /api/v1/accounts/{account_id}/inboxes | List all inboxes
*InboxesApi* | [**updateAgentBot**](docs/Api/InboxesApi.md#updateagentbot) | **POST** /api/v1/accounts/{account_id}/inboxes/{id}/set_agent_bot | Add or remove agent bot
*InboxesApi* | [**updateAgentsInInbox**](docs/Api/InboxesApi.md#updateagentsininbox) | **PATCH** /api/v1/accounts/{account_id}/inbox_members | Update Agents in Inbox
*InboxesApi* | [**updateInbox**](docs/Api/InboxesApi.md#updateinbox) | **PATCH** /api/v1/accounts/{account_id}/inboxes/{id} | Update Inbox
*IntegrationsApi* | [**createAnIntegrationHook**](docs/Api/IntegrationsApi.md#createanintegrationhook) | **POST** /api/v1/accounts/{account_id}/integrations/hooks | Create an integration hook
*IntegrationsApi* | [**deleteAnIntegrationHook**](docs/Api/IntegrationsApi.md#deleteanintegrationhook) | **DELETE** /api/v1/accounts/{account_id}/integrations/hooks/{hook_id} | Delete an Integration Hook
*IntegrationsApi* | [**getDetailsOfAllIntegrations**](docs/Api/IntegrationsApi.md#getdetailsofallintegrations) | **GET** /api/v1/accounts/{account_id}/integrations/apps | List all the Integrations
*IntegrationsApi* | [**updateAnIntegrationsHook**](docs/Api/IntegrationsApi.md#updateanintegrationshook) | **PATCH** /api/v1/accounts/{account_id}/integrations/hooks/{hook_id} | Update an Integration Hook
*MessagesApi* | [**createANewMessageInAConversation**](docs/Api/MessagesApi.md#createanewmessageinaconversation) | **POST** /api/v1/accounts/{account_id}/conversations/{conversation_id}/messages | Create New Message
*MessagesApi* | [**deleteAMessage**](docs/Api/MessagesApi.md#deleteamessage) | **DELETE** /api/v1/accounts/{account_id}/conversations/{conversation_id}/messages/{message_id} | Delete a message
*MessagesApi* | [**listAllMessages**](docs/Api/MessagesApi.md#listallmessages) | **GET** /api/v1/accounts/{account_id}/conversations/{conversation_id}/messages | Get messages
*MessagesAPIApi* | [**createAMessage**](docs/Api/MessagesAPIApi.md#createamessage) | **POST** /public/api/v1/inboxes/{inbox_identifier}/contacts/{contact_identifier}/conversations/{conversation_id}/messages | Create a message
*MessagesAPIApi* | [**listAllConverationMessages**](docs/Api/MessagesAPIApi.md#listallconverationmessages) | **GET** /public/api/v1/inboxes/{inbox_identifier}/contacts/{contact_identifier}/conversations/{conversation_id}/messages | List all messages
*MessagesAPIApi* | [**updateAMessage**](docs/Api/MessagesAPIApi.md#updateamessage) | **PATCH** /public/api/v1/inboxes/{inbox_identifier}/contacts/{contact_identifier}/conversations/{conversation_id}/messages/{message_id} | Update a message
*ProfileApi* | [**fetchProfile**](docs/Api/ProfileApi.md#fetchprofile) | **GET** /api/v1/profile | Fetch user profile
*ReportsApi* | [**getAccountConversationMetrics**](docs/Api/ReportsApi.md#getaccountconversationmetrics) | **GET** /api/v2/accounts/{account_id}/reports/conversations | Account Conversation Metrics
*ReportsApi* | [**getAgentConversationMetrics**](docs/Api/ReportsApi.md#getagentconversationmetrics) | **GET** /api/v2/accounts/{account_id}/reports/conversations/ | Agent Conversation Metrics
*ReportsApi* | [**listAllConversationStatistics**](docs/Api/ReportsApi.md#listallconversationstatistics) | **GET** /api/v2/accounts/{account_id}/reports | Get Account reports
*ReportsApi* | [**listAllConversationStatisticsSummary**](docs/Api/ReportsApi.md#listallconversationstatisticssummary) | **GET** /api/v2/accounts/{account_id}/reports/summary | Get Account reports summary
*TeamsApi* | [**addNewAgentToTeam**](docs/Api/TeamsApi.md#addnewagenttoteam) | **POST** /api/v1/accounts/{account_id}/teams/{team_id}/team_members | Add a New Agent
*TeamsApi* | [**createATeam**](docs/Api/TeamsApi.md#createateam) | **POST** /api/v1/accounts/{account_id}/teams | Create a team
*TeamsApi* | [**deleteATeam**](docs/Api/TeamsApi.md#deleteateam) | **DELETE** /api/v1/accounts/{account_id}/teams/{team_id} | Delete a team
*TeamsApi* | [**deleteAgentInTeam**](docs/Api/TeamsApi.md#deleteagentinteam) | **DELETE** /api/v1/accounts/{account_id}/teams/{team_id}/team_members | Remove an Agent from Team
*TeamsApi* | [**getDetailsOfASingleTeam**](docs/Api/TeamsApi.md#getdetailsofasingleteam) | **GET** /api/v1/accounts/{account_id}/teams/{team_id} | Get a team details
*TeamsApi* | [**getTeamMembers**](docs/Api/TeamsApi.md#getteammembers) | **GET** /api/v1/accounts/{account_id}/teams/{team_id}/team_members | List Agents in Team
*TeamsApi* | [**listAllTeams**](docs/Api/TeamsApi.md#listallteams) | **GET** /api/v1/accounts/{account_id}/teams | List all teams
*TeamsApi* | [**updateATeam**](docs/Api/TeamsApi.md#updateateam) | **PATCH** /api/v1/accounts/{account_id}/teams/{team_id} | Update a team
*TeamsApi* | [**updateAgentsInTeam**](docs/Api/TeamsApi.md#updateagentsinteam) | **PATCH** /api/v1/accounts/{account_id}/teams/{team_id}/team_members | Update Agents in Team
*UsersApi* | [**createAUser**](docs/Api/UsersApi.md#createauser) | **POST** /platform/api/v1/users | Create a User
*UsersApi* | [**deleteAUser**](docs/Api/UsersApi.md#deleteauser) | **DELETE** /platform/api/v1/users/{id} | Delete a User
*UsersApi* | [**getDetailsOfAUser**](docs/Api/UsersApi.md#getdetailsofauser) | **GET** /platform/api/v1/users/{id} | Get an user details
*UsersApi* | [**getSsoUrlOfAUser**](docs/Api/UsersApi.md#getssourlofauser) | **GET** /platform/api/v1/users/{id}/login | Get User SSO Link
*UsersApi* | [**updateAUser**](docs/Api/UsersApi.md#updateauser) | **PATCH** /platform/api/v1/users/{id} | Update a user
*WebhooksApi* | [**createAWebhook**](docs/Api/WebhooksApi.md#createawebhook) | **POST** /api/v1/accounts/{account_id}/webhooks | Add a webhook
*WebhooksApi* | [**deleteAWebhook**](docs/Api/WebhooksApi.md#deleteawebhook) | **DELETE** /api/v1/accounts/{account_id}/webhooks/{webhook_id} | Delete a webhook
*WebhooksApi* | [**listAllWebhooks**](docs/Api/WebhooksApi.md#listallwebhooks) | **GET** /api/v1/accounts/{account_id}/webhooks | List all webhooks
*WebhooksApi* | [**updateAWebhook**](docs/Api/WebhooksApi.md#updateawebhook) | **PATCH** /api/v1/accounts/{account_id}/webhooks/{webhook_id} | Update a webhook object

## Models

- [Account](docs/Model/Account.md)
- [AccountCreateUpdatePayload](docs/Model/AccountCreateUpdatePayload.md)
- [AccountSummary](docs/Model/AccountSummary.md)
- [AccountSummaryPrevious](docs/Model/AccountSummaryPrevious.md)
- [AddNewAgentToAccountRequest](docs/Model/AddNewAgentToAccountRequest.md)
- [AddNewAgentToInboxRequest](docs/Model/AddNewAgentToInboxRequest.md)
- [AddNewAgentToTeamRequest](docs/Model/AddNewAgentToTeamRequest.md)
- [Agent](docs/Model/Agent.md)
- [AgentBot](docs/Model/AgentBot.md)
- [AgentBotCreateUpdatePayload](docs/Model/AgentBotCreateUpdatePayload.md)
- [AgentConversationMetrics](docs/Model/AgentConversationMetrics.md)
- [AgentConversationMetricsMetric](docs/Model/AgentConversationMetricsMetric.md)
- [Article](docs/Model/Article.md)
- [ArticleCreateUpdatePayload](docs/Model/ArticleCreateUpdatePayload.md)
- [AssignAConversationRequest](docs/Model/AssignAConversationRequest.md)
- [AutomationRule](docs/Model/AutomationRule.md)
- [AutomationRuleCreateUpdatePayload](docs/Model/AutomationRuleCreateUpdatePayload.md)
- [BadRequestError](docs/Model/BadRequestError.md)
- [CannedResponse](docs/Model/CannedResponse.md)
- [CannedResponseCreateUpdatePayload](docs/Model/CannedResponseCreateUpdatePayload.md)
- [Category](docs/Model/Category.md)
- [CategoryCreateUpdatePayload](docs/Model/CategoryCreateUpdatePayload.md)
- [Contact](docs/Model/Contact.md)
- [ContactAddLabelsRequest](docs/Model/ContactAddLabelsRequest.md)
- [ContactBase](docs/Model/ContactBase.md)
- [ContactConversationsInner](docs/Model/ContactConversationsInner.md)
- [ContactConversationsInnerAllOfMeta](docs/Model/ContactConversationsInnerAllOfMeta.md)
- [ContactConversationsInnerAllOfMetaSender](docs/Model/ContactConversationsInnerAllOfMetaSender.md)
- [ContactCreate](docs/Model/ContactCreate.md)
- [ContactFilterRequest](docs/Model/ContactFilterRequest.md)
- [ContactFilterRequestPayloadInner](docs/Model/ContactFilterRequestPayloadInner.md)
- [ContactInboxCreationRequest](docs/Model/ContactInboxCreationRequest.md)
- [ContactInboxes](docs/Model/ContactInboxes.md)
- [ContactLabels](docs/Model/ContactLabels.md)
- [ContactListInner](docs/Model/ContactListInner.md)
- [ContactPayload](docs/Model/ContactPayload.md)
- [ContactPayloadContact](docs/Model/ContactPayloadContact.md)
- [ContactSearch200Response](docs/Model/ContactSearch200Response.md)
- [ContactUpdate](docs/Model/ContactUpdate.md)
- [ContactableInboxes](docs/Model/ContactableInboxes.md)
- [Conversation](docs/Model/Conversation.md)
- [ConversationFilterRequest](docs/Model/ConversationFilterRequest.md)
- [ConversationLabels](docs/Model/ConversationLabels.md)
- [ConversationList](docs/Model/ConversationList.md)
- [ConversationListData](docs/Model/ConversationListData.md)
- [ConversationListDataPayloadInner](docs/Model/ConversationListDataPayloadInner.md)
- [ConversationListMeta200Response](docs/Model/ConversationListMeta200Response.md)
- [ConversationListMeta200ResponseMeta](docs/Model/ConversationListMeta200ResponseMeta.md)
- [ConversationMessageCreate](docs/Model/ConversationMessageCreate.md)
- [ConversationShow](docs/Model/ConversationShow.md)
- [ConversationShowAllOfMeta](docs/Model/ConversationShowAllOfMeta.md)
- [ConversationStatusToggle](docs/Model/ConversationStatusToggle.md)
- [ConversationStatusTogglePayload](docs/Model/ConversationStatusTogglePayload.md)
- [CreateANewMessageInAConversation200Response](docs/Model/CreateANewMessageInAConversation200Response.md)
- [CreateAnAccountUserRequest](docs/Model/CreateAnAccountUserRequest.md)
- [CustomAttribute](docs/Model/CustomAttribute.md)
- [CustomAttributeCreateUpdatePayload](docs/Model/CustomAttributeCreateUpdatePayload.md)
- [CustomFilter](docs/Model/CustomFilter.md)
- [CustomFilterCreateUpdatePayload](docs/Model/CustomFilterCreateUpdatePayload.md)
- [DeleteAgentInInboxRequest](docs/Model/DeleteAgentInInboxRequest.md)
- [DeleteAgentInTeamRequest](docs/Model/DeleteAgentInTeamRequest.md)
- [DeleteAnAccountUserRequest](docs/Model/DeleteAnAccountUserRequest.md)
- [ExtendedContact](docs/Model/ExtendedContact.md)
- [GenericId](docs/Model/GenericId.md)
- [GetAccountConversationMetrics200Response](docs/Model/GetAccountConversationMetrics200Response.md)
- [GetSsoUrlOfAUser200Response](docs/Model/GetSsoUrlOfAUser200Response.md)
- [Inbox](docs/Model/Inbox.md)
- [InboxCreationRequest](docs/Model/InboxCreationRequest.md)
- [InboxCreationRequestChannel](docs/Model/InboxCreationRequestChannel.md)
- [IntegrationsApp](docs/Model/IntegrationsApp.md)
- [IntegrationsHook](docs/Model/IntegrationsHook.md)
- [IntegrationsHookCreatePayload](docs/Model/IntegrationsHookCreatePayload.md)
- [IntegrationsHookUpdatePayload](docs/Model/IntegrationsHookUpdatePayload.md)
- [ListAllAccountUsers200ResponseInner](docs/Model/ListAllAccountUsers200ResponseInner.md)
- [ListAllConversationStatistics200ResponseInner](docs/Model/ListAllConversationStatistics200ResponseInner.md)
- [ListAllMessages200ResponseInner](docs/Model/ListAllMessages200ResponseInner.md)
- [Message](docs/Model/Message.md)
- [NewConversation200Response](docs/Model/NewConversation200Response.md)
- [NewConversationRequest](docs/Model/NewConversationRequest.md)
- [NewConversationRequestMessage](docs/Model/NewConversationRequestMessage.md)
- [NewConversationRequestMessageTemplateParams](docs/Model/NewConversationRequestMessageTemplateParams.md)
- [PlatformAccount](docs/Model/PlatformAccount.md)
- [Portal](docs/Model/Portal.md)
- [PortalCreateUpdatePayload](docs/Model/PortalCreateUpdatePayload.md)
- [PublicContact](docs/Model/PublicContact.md)
- [PublicContactCreateUpdatePayload](docs/Model/PublicContactCreateUpdatePayload.md)
- [PublicConversation](docs/Model/PublicConversation.md)
- [PublicConversationCreatePayload](docs/Model/PublicConversationCreatePayload.md)
- [PublicInbox](docs/Model/PublicInbox.md)
- [PublicInboxWorkingHoursInner](docs/Model/PublicInboxWorkingHoursInner.md)
- [PublicMessage](docs/Model/PublicMessage.md)
- [PublicMessageCreatePayload](docs/Model/PublicMessageCreatePayload.md)
- [PublicMessageUpdatePayload](docs/Model/PublicMessageUpdatePayload.md)
- [RequestError](docs/Model/RequestError.md)
- [Team](docs/Model/Team.md)
- [TeamCreateUpdatePayload](docs/Model/TeamCreateUpdatePayload.md)
- [TogglePriorityOfAConversationRequest](docs/Model/TogglePriorityOfAConversationRequest.md)
- [ToggleStatusOfAConversationRequest](docs/Model/ToggleStatusOfAConversationRequest.md)
- [UpdateAgentBotRequest](docs/Model/UpdateAgentBotRequest.md)
- [UpdateAgentInAccountRequest](docs/Model/UpdateAgentInAccountRequest.md)
- [UpdateConversationRequest](docs/Model/UpdateConversationRequest.md)
- [UpdateCustomAttributesOfAConversation200Response](docs/Model/UpdateCustomAttributesOfAConversation200Response.md)
- [UpdateCustomAttributesOfAConversationRequest](docs/Model/UpdateCustomAttributesOfAConversationRequest.md)
- [UpdateInboxRequest](docs/Model/UpdateInboxRequest.md)
- [UpdateInboxRequestChannel](docs/Model/UpdateInboxRequestChannel.md)
- [User](docs/Model/User.md)
- [UserCreateUpdatePayload](docs/Model/UserCreateUpdatePayload.md)
- [Webhook](docs/Model/Webhook.md)
- [WebhookCreateUpdatePayload](docs/Model/WebhookCreateUpdatePayload.md)

## Authorization

Authentication schemes defined for the API:
### userApiKey

- **Type**: API key
- **API key parameter name**: api_access_token
- **Location**: HTTP header


### agentBotApiKey

- **Type**: API key
- **API key parameter name**: api_access_token
- **Location**: HTTP header


### platformAppApiKey

- **Type**: API key
- **API key parameter name**: api_access_token
- **Location**: HTTP header


## Tests

To run the tests, use:

```bash
composer install
vendor/bin/phpunit
```

## Author

hello@chatwoot.com

## About this package

This PHP package is automatically generated by the [OpenAPI Generator](https://openapi-generator.tech) project:

- API version: `1.0.0`
    - Package version: `1.0.0`
    - Generator version: `7.12.0`
- Build package: `org.openapitools.codegen.languages.PhpClientCodegen`
